# Food_Order_Website_Project
 A project assigned by Josh Technology in Round 2 for creating a food order website using HTML, CSS and JavaScript for Front End Developer Role.
